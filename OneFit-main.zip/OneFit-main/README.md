# ![OneFit Logo](https://github.com/vitorserrao/OneFit/blob/main/Onefit.png) 
**OneFit** é um software desenvolvido em WPF e C# com PostgreSQL como banco de dados. O OneFit foi criado para ajuste de aparelhos auditivos e gerenciamento clínico.

## Funcionalidades ⚙️

- 🎧 Ajuste de aparelhos auditivos.
- 📋 Gerenciamento de consultas e prontuários médicos.
- 👥 Cadastro de pacientes.
- 📊 Geração de relatórios.
- 💾 Backup e restauração de dados.

## Tecnologias Utilizadas 💻

- **Linguagem de Programação**: C#
- **Framework**: WPF
- **Banco de Dados**: PostgreSQL

## Instalação 🛠️

Siga os passos abaixo para configurar e rodar o OneFit em seu ambiente local.

1. **Clone o Repositório**

    ```sh
    git clone https://github.com/vitorserrao/OneFit.git
    cd OneFit
    ```

2. **Configure o Banco de Dados PostgreSQL**

    - Crie um banco de dados chamado `onefit`.
    - Configure as credenciais do banco de dados no arquivo de configuração do projeto.

3. **Restaurar Backup do Banco de Dados**

    ```sh
    psql -U seu_usuario -d onefit -f path/to/backup.sql
    ```

4. **Instale as Dependências**

    Certifique-se de ter o .NET Framework instalado em seu sistema. Abra o projeto no Visual Studio e restaure as dependências do NuGet.

5. **Compile e Execute o Projeto**

    Compile o projeto no Visual Studio e execute.

## Autores ✍️

- **Vitor Serrão**
- **Angelo Lara**
- **Luiz**
- **Lucas**

## Licença 📜

Este projeto é licenciado sob os termos da licença [MIT](LICENSE).

---

![GitHub](https://img.shields.io/badge/GitHub-repo-blue?style=flat-square&logo=github)
![WPF](https://img.shields.io/badge/WPF-.NET-blueviolet?style=flat-square&logo=.net)
![PostgreSQL](https://img.shields.io/badge/PostgreSQL-db-blue?style=flat-square&logo=postgresql)
